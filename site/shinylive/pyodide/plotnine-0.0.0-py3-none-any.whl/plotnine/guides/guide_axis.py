from .guide import guide


class guide_axis(guide):
    """
    Axis
    """

    # parameter
    available_aes = {"x", "y"}

    def draw(self):
        pass
